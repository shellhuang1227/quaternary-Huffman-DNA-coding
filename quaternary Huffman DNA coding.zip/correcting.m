function msg1=correcting(code,n,k)
%%
%���������
h=hammgen(n-k);
gen=gen2par(h);
syndrome = rem(code * h', 4);
ErrNum=zeros(size(code,1),1);
for i=1:size(code,1)
    ErrNumLoc=find(syndrome(i,:),1);
    if ~isempty(ErrNumLoc)
        ErrNum(i,1)=syndrome(i,ErrNumLoc);
    end
end
if ~isempty(find(ErrNum, 1))
    ErrNum=repmat(ErrNum,1,size(code,2));
    syndrome(syndrome>0)=1;
    err = bi2de(fliplr(syndrome));
    trt=syndtable(h);
    err_loc = trt(err + 1, :);
    code=rem(code+(4-err_loc.*ErrNum),4);
end
clear syndrome ErrNum err trt err_loc
%%
%ȥ��������
I = eye(k);
if isequal(gen(:, 1:k) ,I)
    msg1 = code(:, 1:k);
elseif isequal(gen(:, n-k+1:n), I)
    msg1 = code(:, n-k+1:n);
else
    error(message('comm:decode:InvalidGenMatrixForm'));
end