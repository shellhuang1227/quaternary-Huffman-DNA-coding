function [compATCG]=ATCG(code)
%%
code=reshape(code',[],1);
compATCG=num2str(code)';
a=size(compATCG,1)*size(compATCG,2);
b=floor(a/465);
c=mod(a,465);
%%
if c==0
    compATCG=reshape(compATCG,465,b)';
    %compATCG=cellstr(compATCG);
else
    CutCompATCG=compATCG(1:a-c);
    CutCompATCG=reshape(CutCompATCG,465,b)';
    compATCG=char(CutCompATCG,compATCG(end-c+1:end));
end

%%
compATCG(compATCG=='0')='A';
compATCG(compATCG=='1')='T';
compATCG(compATCG=='2')='C';
compATCG(compATCG=='3')='G';
end
