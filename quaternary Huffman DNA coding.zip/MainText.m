function  [number,dict,avglen,TextData,compATCG,allavglen,time,IsEqual,TextData1,result,err_num_after]=MainText(textfile,allnumber,n,k)
loc=find(textfile=='.');
suffix=textfile(loc(end)+1:end);
%%
%�����ı���ת������
% tic
[BinSer,TextData]=Text2Bin(textfile);
% toc
%%
% result=struct('prob','','symbols','','BinSerNew','','dict','','avglen','','time','','number','');
result=struct('number','','avglen','','efficiency','','size_dict','','time','','symbols','','dict','','BinSerNew','');
for i=1:length(allnumber)
    tic
    number=allnumber(i);
    %�������
    %     [result(number).prob,result(number).symbols,result(number).BinSerNew]=GetProperbilityFast(BinSer,number);
    [prob,result(number).symbols,result(number).BinSerNew]=GetProperbilityFast(BinSer,number);
    fprintf('number=%dʱ�ĸ��ʼ������    ',number)
    %���ɱ����ļ�
    %     [result(number).dict,result(number).avglen] = huffmandict(result(number).symbols,result(number).prob, 4);%��������һ�μ���Ĵ����Ҹ�ע�͵��ˣ�����ʱ��̫��
    [result(number).dict,result(number).avglen] = huffmandict(result(number).symbols,prob, 4);
    fprintf('���ֵ����    ')
    result(number).time=toc;
    %
    dict=result(number).dict;
    save('dict','dict')
    D=dir('dict.mat');
    result(number).size_dict=D.bytes/1024;
    delete dict.mat
    fprintf('���ֵ����\n')
    %
    result(number).efficiency=number/result(number).avglen;
    %
    result(number).number=number;
    
    
end
clear BinSer prob symbols dict D i number
%%
%ɾ��result�еĿ�Ԫ����
a=[];
for i=1:length(result)
    if isempty(result(i).number)
        a=[a,i];
    end
end
result(a)=[];
clear a
%%
%ѡ��Ч����ߵ�number
[number,dict,avglen,BinSerNew,allavglen,time]=Choose(result,allnumber);
%%
result = rmfield(result, 'BinSerNew');
result = rmfield(result, 'dict');
%%
%���ļ����б���
comp = huffmanenco(BinSerNew,dict);
compAdd=AddAddress(comp,suffix);
%���������
h=hammgen(n-k);gen=gen2par(h);[msg, ~] = vec2mat(compAdd, k);
code = rem(msg * gen, 4);code(:,1:n-k)=rem(4-code(:,1:n-k),4);
%���ATCG
compATCG=ATCG(code);
%%
%������ɴ���
code1=code;
% code=gen_err(code,percentage);
code=gen_err(code,0.01);
% for i=1:size(code,1)
%     code(i,unidrnd(size(code,2)))=unidrnd(4)-1;
% end

%%
%
msg1=correcting(code,n,k);%����ɾ���˾�����
%%
%ɾ��10λ��ַλ
msg1=DelAddress(msg1);
msg1=msg1(1:length(comp));

%%
%����
if isequal(msg1,comp)
    dsig = huffmandeco(msg1,dict);
    %%
    % %������תʮ����
    % %����Ӣ�ĵ�
    % if number==4
    %     dsigOdd=dsig(1:2:end);
    %     dsigEven=dsig(2:2:end);
    %     dsigNew=cellfun(@strcat, dsigOdd,dsigEven,'Unif', 0 );
    % elseif number==8
    %     dsigNew=dsig;
    % elseif number==16
    %     dsigChar16=char(dsig);
    %     dsigNew=cell(length(dsigChar16)*2,1);
    %     for i=1:(length(dsigChar16))
    %         dsigNew{2*i-1}=dsigChar16(i,1:8);
    %         dsigNew{2*i}=dsigChar16(i,9:16);
    %     end
    % else
    %     disp('�һ�û��д����֧��');
    %     time=toc;
    %     IsEqual=0;
    %     return
    % end
    % ddd=find(ismember(dsigNew,{'00001101'}));
    % ddd=[0;ddd];
    % TextNew=char(bin2dec(dsigNew));
    % TextData1=cell(length(ddd)-1,1);
    % for i=1:length(ddd)-1
    %     TextData1(i,1)=cellstr(TextNew(ddd(i)+1:ddd(i+1)-1)');
    % end
    % IsEqual=isequal(TextData,TextData1);
    %%
    %�������ĵ�
    if number==8
        dsigOdd=dsig(1:2:end);
        dsigEven=dsig(2:2:end);
        dsigNew=cellfun(@strcat, dsigOdd,dsigEven,'Unif', 0 );
        
    elseif number==16
        dsigNew=dsig;
    elseif number==32
        dsigChar16=char(dsig);
        dsigNew=cell(length(dsigChar16)*2,1);
        for i=1:(length(dsigChar16))
            dsigNew{2*i-1}=dsigChar16(i,1:16);
            dsigNew{2*i}=dsigChar16(i,17:32);
        end
    else
        disp('�һ�û��д����֧��');
        time=toc;
        IsEqual=0;
        return
    end
    ddd=find(ismember(dsigNew,{'0000110100001101'}));
    ddd=[0;ddd];
    TextNew=char(bin2dec(dsigNew));
    TextData1=cell(length(ddd)-1,1);
    for i=1:length(ddd)-1
        TextData1(i,1)=cellstr(TextNew(ddd(i)+1:ddd(i+1)-1)');
    end
    IsEqual=isequal(TextData,TextData1);
else
    fprintf('���������ˣ����ܽ���')
    IsEqual=0;
    pos=(mag1==comp);
    err_num_after=sum(sum(~pos));
end
end
