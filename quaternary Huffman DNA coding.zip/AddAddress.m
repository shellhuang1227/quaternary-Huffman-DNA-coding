function [compATCG]=AddAddress(comp,suffix)
%%
compATCG=num2str(comp)';
a=size(compATCG,1)*size(compATCG,2);
b=floor(a/380);
c=mod(a,380);
%%
if c==0
    compATCG=reshape(compATCG,380,[])';
    compATCG=cellstr(compATCG);
else
    CutCompATCG=compATCG(1:a-c);
    CutCompATCG=reshape(CutCompATCG,380,b)';
    compATCG=char(CutCompATCG,compATCG(end-c+1:end));
end
%%
%10λ��ַλ
if suffix=='txt'
    AddCompATCG1='001';
else
    AddCompATCG1='002';
end
AddCompATCG2=dec2bin(1:size(compATCG,1),17);
for i=1:size(AddCompATCG2,1)
    AddCompATCG(i,:)=[AddCompATCG1,AddCompATCG2(i,:)];
end
compATCG=[AddCompATCG,compATCG];
compATCG=str2num(reshape(compATCG',[],1));

%%
% compATCG(compATCG=='0')='A';
% compATCG(compATCG=='1')='T';
% compATCG(compATCG=='2')='C';
% compATCG(compATCG=='3')='G';
end
