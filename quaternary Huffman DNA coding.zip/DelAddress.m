function [compATCG]=DelAddress(msg1)
%%
msg1=reshape(msg1',[],1);
compATCG=num2str(msg1)';
a=size(compATCG,1)*size(compATCG,2);
b=floor(a/400);
c=mod(a,400);
%%
if c==0
    compATCG=reshape(compATCG,400,b)';
else
    CutCompATCG=compATCG(1:a-c);
    CutCompATCG=reshape(CutCompATCG,400,b)';
    compATCG=char(CutCompATCG,compATCG(end-c+1:end));
end
%%
%ȥ��10λ��ַλ
compATCG(:,1:20)=[];
compATCG=str2num(reshape(compATCG',[],1));
end
