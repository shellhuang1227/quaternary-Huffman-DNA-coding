% function  [number,dict,avglen,imdata,compATCG,allavglen,time,IsEqual]=MainImage(imagefile,allnumber,n,k)
function  [number,dict,avglen,imdata,compATCG,allavglen,time]=MainImage(imagefile,allnumber,n,k)
loc=find(imagefile=='.');
suffix=imagefile(loc(end)+1:end);
%%
tic
%���ǲ�ɫͼƬ
%��ͼƬתΪ������char����
% imdata = imread(imagefile);
% BinSer=dec2bin(imdata,8);
% BinSer=BinSer';
% BinSer=reshape(BinSer,1,[]);
% %%���Ǻڰ�ͼƬ
imdata=imread(imagefile);
BinSer=strrep(num2str(double(reshape(imdata,1,[]))),' ','');
%%
% result=struct('prob','','symbols','','BinSerNew','','dict','','avglen','','number','','time','','efficienccy','');
result=struct('number','','avglen','','efficiency','','size_dict','','time','','symbols','');
for i=1:length(allnumber)
    tic
    number=allnumber(i);
    [prob,result(number).symbols,BinSerNew]=GetProperbilityFast(BinSer,number);
    fprintf('number=%dʱ�ĸ��ʼ������    ',number)
    %���ɱ����ļ�
%     [result(number).dict,result(number).avglen] = huffmandict(result(number).symbols,result(number).prob, 4);%��������һ�μ���Ĵ����Ҹ�ע�͵��ˣ�����ʱ��̫��
    [dict,result(number).avglen] = huffmandict(result(number).symbols,prob, 4);
    fprintf('���ֵ����    ')
    
    result(number).time=toc;
    %
    save('dict','dict')
    D=dir('dict.mat');
    result(number).size_dict=D.bytes/1024;
    delete dict.mat
    fprintf('���ֵ����\n')
    %
    result(number).efficiency=number/result(number).avglen;
    %
    result(number).number=number;

end
%%
%ɾ��result�еĿ�Ԫ����
a=[];
for i=1:length(result)
    if isempty(result(i).number)
        a=[a,i];
    end
end
result(a)=[];
clear a
%%
[number,dict,avglen,BinSerNew,allavglen]=Choose(result,allnumber);
%%
%���ļ����б���
comp = huffmanenco(BinSerNew,dict);
compAdd=AddAddress(comp,suffix);
%���������
h=hammgen(n-k);gen=gen2par(h);[msg, ~] = vec2mat(compAdd, k);
code = rem(msg * gen, 4);code(:,1:n-k)=rem(4-code(:,1:n-k),4);
%���ATCG
compATCG=ATCG(code);
%%
%������ɴ���
code1=code;
for i=1:size(code,1)
    code(i,unidrnd(size(code,2)))=unidrnd(4)-1;
end
%%
%
msg1=correcting(code,n,k);
%%
%ɾ��10λ��ַλ
msg1=DelAddress(msg1);
msg1=msg1(1:length(comp));
%%
%����
%tic
% dsig = huffmandeco(msg1,dict);
% %%
% %���Ǻڰ׵�ͼƬ
% dsigNew=char(dsig)';
% dsigNew=reshape(dsigNew,1,[]);
% dsigNew=dsigNew(1:size(imdata,1)*size(imdata,2));
% imdataNew=logical(double(reshape(dsigNew,size(imdata,1),size(imdata,2)))-48);
%%
%�����ǲ�ɫͼƬ
%������תʮ����
% if number==4
%     dsigOdd=dsig(1:2:end);
%     dsigEven=dsig(2:2:end);
%     dsigNew=cellfun(@strcat, dsigOdd,dsigEven,'Unif', 0 );
% elseif number==8
%     dsigNew=dsig;
% elseif number==16
%     dsigChar16=char(dsig);
%     dsigNew=cell(length(dsigChar16)*2,1);
%     for i=1:(length(dsigChar16))
%         dsigNew{2*i-1}=dsigChar16(i,1:8);
%         dsigNew{2*i}=dsigChar16(i,9:16);
%     end
% %��ûд��ע�����ﲻ̫��
% % elseif number==32
% %     dsigChar32=char(dsig);
% %     dsigNew=cell(length(dsigChar32)*2,1);
% %     for i=1:(length(dsigChar32))
% %         dsigNew{2*i-1}=dsigChar32(i,1:8);
% %         dsigNew{2*i}=dsigChar32(i,9:16);
% %     end
% else
%     disp('�һ�û��д����֧��');
%     time=toc;
%     IsEqual=0;
%     return
% end
% dsigBin=bin2dec(dsigNew);
% 
% imdataNew=uint8(reshape(dsigBin,size(imdata,1),size(imdata,2),size(imdata,3)));
% IsEqual=isequal(imdata,imdataNew);
time=toc;
end
