function [prob,symbols,BinSerNew,AddStrNum]=GetProperbilityFast(a,digit)
aa=mod(length(a),digit);
AddStrNum=digit-aa;
a=[a,strrep(num2str(zeros(1,AddStrNum)),' ','')];%����������ĩβ��0
BinSerNew=cell(length(a)/digit,1);
for i=1:(length(a)/digit)
    BinSerNew{i}=a((i*digit-digit+1):(i*digit));
end

%%

ccc= ismember(BinSerNew,{'        '});
BinSerNew(ccc)=[];

%%
%����ʣ�result��һ����symbols���ڶ�����prob

number=digit;

%%

BinSerNewDec=bin2dec(BinSerNew);

%%
UniBinSerNewDec=unique(BinSerNewDec);
count = hist(BinSerNewDec,UniBinSerNewDec)';
prob=count/length(BinSerNewDec);clear BinSerNewDec
symbols=cellstr(dec2bin(UniBinSerNewDec,number));

%%


return