function [number,dict,avglen,BinSerNew,allavglen,time]=Choose(result,allnumber)
allavglen=[result.avglen];
[~,number]=min(allavglen./(allnumber/2));
dict=result(number).dict;
avglen=result(number).avglen;
BinSerNew=result(number).BinSerNew;
time=result(number).time;
number=result(number).number;

end

