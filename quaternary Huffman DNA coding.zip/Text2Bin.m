function [BinSer,TextData]=Text2Bin(textfile)

fileID = fopen(textfile);
TextData=textscan(fileID,'%s');
fclose(fileID);
TextData=TextData{1,1};
%TextDataStr=char(TextData)';


%BinSerStr={};
%%


LenTextData=[0;cellfun('length',TextData)];
BinSerStr=cell(sum(LenTextData),1);

for i=1:size(TextData,1)
    %BinSerTem=[dec2bin(char(TextData(i,1)),8);'00001101'];%Ӣ��
    BinSerTem=[dec2bin(char(TextData(i,1)),16);'0000110100001101'];%����
    %BinSerStr=[BinSerStr;cellstr(BinSerTem)];
    BinSerStr(sum(LenTextData(1:i))+i:sum(LenTextData(1:i+1))+i)=cellstr(BinSerTem);
end

aaaa=find(ismember(BinSerStr,{'00000000'}));%�ҵ����ַ�null
if(~isempty(aaaa))
    BinSerStr(aaaa)=[];
end
clear aaaa
%%
BinSer111=char(BinSerStr)';
BinSer=reshape(BinSer111,1,[]);


end